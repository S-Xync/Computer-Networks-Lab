****create a file named server.txt in server folder
gcc server.c -o server -lpthread
./server
gcc client.c -o client
